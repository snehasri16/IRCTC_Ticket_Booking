package org.ticket.booking.services;

public class TrainService {

}
